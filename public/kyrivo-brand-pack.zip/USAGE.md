# KYRIVO — SYSTÈME DE LOGO FINAL (Origami K v2)

Direction figée. Quatre rôles, une seule identité :
flat = produit · or = communication · verre = app icon/avatar · hero = marketing.

## Quelle version utiliser où

| Contexte | Fichier |
|---|---|
| App (sidebar, navigation, états) | `svg/kyrivo-symbol-dark.svg` (ou `-mono` recoloré via currentColor) |
| Écran de connexion, header app | `svg/kyrivo-logo-primary-dark.svg` |
| Emails (header, fond #0B0B0D) | `png/kyrivo-logo-dark-2000.png` redimensionné ≈ 180 px de large |
| Factures, exports, documents (fond blanc) | `svg/kyrivo-logo-primary-light.svg` / `png/kyrivo-logo-light-2000.png` |
| Fond clair en général | versions `-light` (facette claire densifiée #F0A80C pour tenir sur blanc) |
| Pubs Meta, bannières, open-graph, hero landing | `kyrivo-hero-marketing` (svg ou png 2400) ; symbole or `kyrivo-symbol-gold.svg` pour les compositions custom |
| Favicon navigateur | `png/favicon-32.png` + `png/favicon-16.png` (+ `svg/kyrivo-favicon.svg` en favicon SVG moderne) |
| Avatar réseaux sociaux, vignettes | `png/kyrivo-avatar-512.png` (verre, plein cadre — les plateformes arrondissent) |
| iOS / écran d'accueil | `png/apple-touch-icon.png` (180 px, plein cadre) |

## Tailles minimales

- Symbole flat : 16 px (en dessous de 24 px, préférer le favicon, géométrie épaissie sans pli central).
- Lockup horizontal : 120 px de large ; en dessous, symbole seul.
- Wordmark seul : 90 px de large minimum.
- Hero : ne jamais l'utiliser sous 480 px de large.

## Marges de protection

Zone vide obligatoire autour du logo = largeur du fût du K (≈ 1/5 de la hauteur du symbole), sur les 4 côtés. Rien ne pénètre cette zone : ni texte, ni bord, ni autre logo.

## Règles de couleur

- Le symbole est toujours amber (4 tons : #FBBF24 / #F59E0B / #D97706 / #B45309) ou monochrome. Jamais d'autre teinte.
- Or et verre = marketing uniquement. Dans le produit, toujours le flat : le contraste « spectaculaire dehors, sobre dedans » est volontaire.
- Wordmark : #F8FAFC sur sombre, #111317 sur clair. Le wordmark est vectorisé (aucune police requise).

## Erreurs à éviter

1. Déformer, incliner, étirer, ajouter une ombre portée ou un contour.
2. Utiliser l'or ou le verre dans l'interface de l'app ou sur les factures.
3. Poser la version dark sur fond clair (wordmark blanc invisible) — et inversement.
4. Recomposer le wordmark dans une police : utiliser uniquement les tracés fournis.
5. Mettre le favicon sans sa tuile charcoal (perte de contraste dans les onglets clairs).
6. Encadrer le symbole dans un cercle ou un carré supplémentaire.

## Note technique

- SVG sans dépendance externe (wordmark en tracés). Compatible Next.js / SVGR.
- PNG : fonds transparents pour symboles et lockups ; hero et icônes sur fond propre.
- favicon.ico si besoin : combiner favicon-16 + favicon-32 (ex. `magick favicon-16.png favicon-32.png favicon.ico`).
